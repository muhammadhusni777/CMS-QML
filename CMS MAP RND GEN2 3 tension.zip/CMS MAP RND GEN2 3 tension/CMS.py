import time
import sys
import csv
import datetime as dt

import math

from math import sin, cos, sqrt, atan2, radians
import random  

from math import pow
phi = math.pi
from PyQt5.QtCore import QUrl, QObject, pyqtSignal, pyqtSlot, QTimer, pyqtProperty
from PyQt5.QtGui import QGuiApplication, QIcon
from PyQt5.QtQuick import QQuickView
from PyQt5.QtQml import QQmlApplicationEngine
from PyQt5.QtWidgets import QApplication, QCheckBox, QGridLayout, QGroupBox
import threading 



import paho.mqtt.client as paho

broker="127.0.0.1"
port = 1883

pubdelay = 2 #delay publish to all wind and engine box
counter = 0

print(str("SYERGIE CABLE MANAGEMENT SYSTEM"))
print(str("=(c)PT SYERGIE INDOPRIMA 2022="))
print(str("                              "))
print(str("                              "))

aggresivity_time = 0
aggresivity_time_prev = 0
aggresivity_value = 1
max_aggresivity_value = 2

target_lat =0
target_long = 0
error_long =0
error_lat = 0
x_ship = 123 
y_ship = 67
distance = 0

Wspeed=0
Wdirect=0

val_latitude = -2.75819  #centre
filtered_val_latitude = -2.75819   #centre
val_longitude = 105.787  #centre
filtered_val_longitude = 105.787  #centre

delta_latitude = 0
delta_longitude = 0
knot = 0
prev_val_latitude = val_latitude
prev_val_longitude = val_longitude


Lat_G = -0.5942511
Lon_G = 123.8169180
heading = 0


get_lat_GUI = 0
get_lon_GUI = 0
get_lat_GUI1 = 0
get_lon_GUI1 = 0
get_lat_GUI_last = 0
get_lon_GUI_last = 0
counter_distance_mea = 0
dst_bw_line = 0

station_keeping_state = 0

delta_lat = 0
delta_lat = 0

heading_Grep = 0
distance_Grap=0
distance_Grap_m = 0
heading_G = 0

message_time = 0
message_time_prev = 0

mqtt_transmit_time = 0
mqtt_transmit_time_prev = 0

day = 0
day_prev = 0

current_time = dt.datetime.now()

aggresivity_coefficient = 0

minval = 0
thruster_mode = ""

water_depth = 0

payout_speed_ms = 0
payout_speed_knot = 0


payout_memory_file = open("payout_memory.txt","r+")

payout_memory = 0
try:
    payout_memory = float(payout_memory_file.read())
except ValueError:
    payout_memory_file = open("payout_memory.txt","w")
    payout_memory_file.write(str(0.00001))

print(str("payout memory : ") + str(payout_memory))
payout= float(payout_memory)
payout_prev = float(payout_memory)


payout2_memory_file = open("payout2_memory.txt","r+")
payout2_memory = 0


try:
    payout2_memory = float(payout2_memory_file.read())
except ValueError:
    payout2_memory_file = open("payout2_memory.txt","w")
    payout2_memory_file.write(str(0.00001))


print(str("payout memory 2 : ") + str(payout2_memory))
payout2= float(payout2_memory)
payout2_prev = float(payout2_memory)


payout_memory_time = time.time()
payout_memory_time_prev = time.time()

tension_offset_txt = open("tension_offset.txt","r+")
tension_offset = float(tension_offset_txt.read())


tension2_offset_txt = open("tension2_offset.txt","r+")
tension2_offset = float(tension2_offset_txt.read())


meter_payout_buffer = 0

y_max_payout = 160


tension = 0
tension_raw = 0

tension2 = 0
tension2_raw = 0

y_max_time = 0
y_max_time_prev = 0

calculation_time = 0
calculation_time_prev = 0

loadcell_constanta = 0.000001034
loadcell2_constanta = 0.000001034

ship_time = 0
ship_time_prev = 0

capstan_button = "off"
capstan_potensiometer = ""
capstan_target = 0

cable_type = ""


line_dot = 0

dot1_lat = 0
dot1_long = 0
dot2_lat = 0
dot2_long = 0
dot3_lat = 0
dot3_long = 0
dot4_lat = 0
dot4_long = 0
dot5_lat = 0
dot5_long = 0
dot6_lat = 0
dot6_long = 0

imaginary_line = "false"

def reMap(value, maxInput, minInput, maxOutput, minOutput):

    value = maxInput if value > maxInput else value
    value = minInput if value < minInput else value

    inputSpan = maxInput - minInput
    outputSpan = maxOutput - minOutput

    scaledThrust = float(value - minInput) / float(inputSpan)

    return minOutput + (scaledThrust * outputSpan)



class MQTTValue(QQuickView):
    def __init__(self):
        super(MQTTValue,self).__init__()
        self.setSource(QUrl('main.qml'))
   

    @pyqtSlot(result=int)
    def y_max_payout(self):  return y_max_payout
    
    @pyqtSlot(result=int)
    def y_max_tension(self):  return y_max_tension

    @pyqtSlot(result=float)
    def lat(self):  return val_latitude

    @pyqtSlot(result=float)
    def long(self):  return val_longitude

    @pyqtSlot(result=float)
    def headingship(self):  return heading

    @pyqtSlot(result=float)
    def winddirect(self):  return Wdirect

    @pyqtSlot(result=float)
    def windspeed(self):  return Wspeed

    @pyqtSlot(result=float)
    def ship_x(self):  return x_ship

    @pyqtSlot(result=float)
    def ship_y(self):  return y_ship

    @pyqtSlot(result=float)
    def lat_target(self):  return target_lat

    @pyqtSlot(result=float)
    def long_target(self):  return target_long

    @pyqtSlot(result=float)
    def long_error(self):  return error_long  

    @pyqtSlot(result=float)
    def lat_error(self):  return error_lat
    
    @pyqtSlot(result=float)
    def distance_read(self):  return round(distance_Grap_m,3)
    
    @pyqtSlot(result=float)
    def knot_read(self):  return round(knot,2)
    
    
    @pyqtSlot(result=float)
    def dot_lat1_read(self):  return dot1_lat
    
    @pyqtSlot(result=float)
    def dot_long1_read(self):  return dot1_long
    
    @pyqtSlot(result=float)
    def dot_lat2_read(self):  return dot2_lat
    
    @pyqtSlot(result=float)
    def dot_long2_read(self):  return dot2_long
    
    @pyqtSlot(result=str)
    def imaginary_line_read(self):  return imaginary_line
    
    @pyqtSlot(float)
    def get_lat (self, lat_GUI):
        global get_lat_GUI
        get_lat_GUI = float(lat_GUI)
        print("Lat = ", get_lat_GUI)

    @pyqtSlot(float)
    def get_lon (self, lon_GUI):
        global get_lon_GUI
        get_lon_GUI = float(lon_GUI)
        print("Lon = ", get_lon_GUI)

    @pyqtSlot(float)
    def get_lat1 (self, lat_GUI1):
        global get_lat_GUI1
        get_lat_GUI1 = float(lat_GUI1)
        print("Lat 1= ", get_lat_GUI1)

    @pyqtSlot(float)
    def get_lon1 (self, lon_GUI1):
        global get_lon_GUI1
        global delta_lat
        global delta_lon
        global distance
        get_lon_GUI1 = float(lon_GUI1)
        delta_lat = (get_lat_GUI - get_lat_GUI1)*111132
        delta_lon = (get_lon_GUI - get_lon_GUI1)*111132
        distance = sqrt(pow(delta_lat, 2) +  pow(delta_lon, 2))
        print("Lon 1= ", get_lon_GUI1)
        print("delta lat= ", delta_lat)
        print("delta lon= ", delta_lon)
        print("distance= ", distance)
    
    
    
    
    @pyqtSlot(float, float)
    def get_dot (self, lat_GUI, lon_GUI):
        global get_lat_GUI
        global line_dot
        
        global dot1_lat
        global dot1_long
        global dot2_lat
        global dot2_long
        global dot3_lat
        global dot3_long
        global dot4_lat
        global dot4_long
        global dot5_lat
        global dot5_long
        global dot6_lat
        global dot6_long
        global imaginary_line
        
        line_dot = line_dot + 1
        
        get_lat_GUI = float(lat_GUI)
        get_lon_GUI = float(lon_GUI)
        
        if (line_dot == 1):
            dot1_lat = get_lat_GUI
            dot1_long = get_lon_GUI
            print("dot 1 :" + str(dot1_lat) + ","+ str(dot1_long))
            imaginary_line = "false"
            print(imaginary_line)
            
        if (line_dot == 2):
            dot2_lat = get_lat_GUI
            dot2_long = get_lon_GUI
            print("dot 2 :" + str(dot2_lat) + ","+ str(dot2_long))
            imaginary_line = "true"
            line_dot = 0
            print(imaginary_line)
            
            
        
    @pyqtSlot(float)
    def manual_capstan_speed(self, val):
        global manual_capstan_speed
        manual_capstan_speed = val
        pwm = manual_capstan_speed * 2.5
        print(pwm)
        
    
    @pyqtSlot(float)
    def water_depth (self, get_water_depth):
        if (get_water_depth == ""):
            get_water_depth = 0
        global water_depth
        water_depth = int(get_water_depth)
       # print(water_depth)
    
    @pyqtSlot(str)
    def cms_button (self, command):
        print(command)
        if (command == "reset"):
            global payout_prev
            global payout
            payout_memory_file = open("payout_memory.txt","w")
            payout_memory_file.write(str(0.00001))
            payout_prev = 0
            client.publish("payout_reset","yes") 
            #payout = 0
            meter_payout_buffer = 0
            
            
        if (command == "reset2"):
            global payout2_prev
            global payout2
            payout2_memory_file = open("payout2_memory.txt","w")
            payout2_memory_file.write(str(0.00001))
            payout2_prev = 0
            client.publish("payout2_reset","yes") 
            #payout = 0
            meter_payout2_buffer = 0
        
        if (command == "zero"):
            global tension_offset
            tension_offset = tension_raw
            #.txt
            tension_offset_txt = open("tension_offset.txt","w")
            tension_offset_txt.write(str(tension_offset))
            
        if (command == "zero2"):
            global tension2_offset
            tension2_offset = tension2_raw
            #.txt
            tension2_offset_txt = open("tension2_offset.txt","w")
            tension2_offset_txt.write(str(tension2_offset))
    
    
    @pyqtSlot(result=int)
    def distance_bw_line(self):return distance 
    
    @pyqtSlot(result=int)
    def payout_read(self):
        return payout
    
    
    @pyqtSlot(result=int)
    def payout2_read(self):
        return payout2
        
    
    @pyqtSlot(result=float)
    def payout_speed_read(self):return round(payout_speed_ms , 2)
    
    @pyqtSlot(result=float)
    def payout2_speed_read(self):return round(payout2_speed_ms , 2)
        
    @pyqtSlot(result=float)
    def tension_read(self):return tension
    
    @pyqtSlot(result=float)
    def tension2_read(self):return tension2
    
    @pyqtSlot(result=float)
    def graphnel_latitude(self):return  Lat_G 

    @pyqtSlot(result=float)
    def graphnel_longitude(self):return Lon_G 

    @pyqtSlot(result=float)
    def heading_G(self):return heading_Grep
    
    @pyqtSlot('QString')
    def setMinVal(self, value):
        global min_thruster
        datatext =str(value)
        if (datatext == ""):
            datatext = 0           
        #print (datatext)
    
    @pyqtSlot('QString')
    def setMaxVal(self, value):
        global max_thruster      
        datatext =str(value)
        if (datatext == ""):
            datatext = 0
        max_thruster = float(datatext)
        #print (datatext)
    
    
    @pyqtSlot('QString')
    def thrusterMode(self, value):
        global thruster_mode        
        thruster_mode =str(value)        
        
    @pyqtSlot('QString')
    def setAggresivity(self, value):
        global aggresivity_coefficient      
        datatext =str(value)
        if (datatext == ""):
            datatext = 0           
        #print (datatext)
        aggresivity_coefficient = float(datatext)

    
    @pyqtSlot('QString')
    def capstan_potensiometer(self, value):
        global capstan_potensiometer
        capstan_potensiometer = value
        #print(capstan_potensiometer)
        
        
    @pyqtSlot('QString')
    def cable_type(self, value):
        global cable_type
        cable_type = value
        #print(cable_type)
        
        
    @pyqtSlot('QString')
    def capstan_target(self, value):
        global capstan_target
        capstan_target = value
        #print(cable_type)
        
    @pyqtSlot('QString')
    def capstan_button(self, value):
        global capstan_button
        capstan_button = value
        print(capstan_button)


def on_message(client, userdata, message):
        msg = str(message.payload.decode("utf-8"))
        t = str(message.topic)

        if(msg[0] == 'c'):
            val =  1
        else:
            val = (msg)


        if (t == "station_keeping"):
            global station_keeping_state
            station_keeping_state = val



        if (t == "GPS/lat"):
            global val_latitude
            val_latitude = float(msg)


        if (t == "GPS/long"):
            global val_longitude
            val_longitude = float(msg)

        if (t == "payout"):
            global meter_payout_buffer
            meter_payout_buffer = float(msg)
            #print(payout)
            
            
        if (t == "payout2"):
            global meter_payout2_buffer
            meter_payout2_buffer = float(msg)
            #print(meter_payout2_buffer)
            
        if (t == "tension"):
            global tension_raw
            tension_raw = float(msg) * loadcell_constanta
            
        if (t == "tension2"):
            global tension2_raw
            tension2_raw = float(msg) * loadcell2_constanta
            #print(tension2_raw)

                
            
        if (t == "headingship"):
            global heading
            global heading_Grep
            heading = float(msg)
            
            heading_Grep = heading
            #print(heading_Grep)
        
        
        if (t == "winddirect"):
            global Wdirect
            Wdirect = float(msg)

        if (t == "windspeed"):
            global Wspeed
            Wspeed = float(msg)


        
#save csv
def timerEvent():
    global time
    global message_time
    global message_time_prev
    global mqtt_transmit_time
    global mqtt_transmit_time_prev
    global day
    global day_prev
    
    
    global Lat_G
    global Lon_G
    
    global water_depth
    global calculation_time
    global calculation_time_prev

   
    global y_max_time
    global y_max_time_prev
    
    
    global payout
    global meter_payout_buffer
    global payout_memory
    
    global payout2
    global meter_payout2_buffer
    global payout2_memory
    
    global payout_memory_time
    global payout_memory_time_prev
    
    global payout_prev
    global payout_speed_ms
    
    global payout2_prev
    global payout2_speed_ms
    
    global distance_Grap
    global distance_Grap_m
    
    global tension
    global tension2
    
    global ship_time
    global ship_time_prev
    
    global delta_latitude
    global delta_longitude
    
    global knot
    global prev_val_latitude
    global prev_val_longitude
    
    
##############################COUNT PAYOUT##################################
    payout_memory_time = time.time() - payout_memory_time_prev
    
    payout_memory_file = open("payout_memory.txt","r+")
    try:
        payout_memory = float(str(payout_memory_file.read()))
    except ValueError:
        pass
    
    try:
        payout2_memory_file = open("payout2_memory.txt","r+")
    except ValueError:
        pass
    
    try:
        payout2_memory = float(str(payout2_memory_file.read()))
    except ValueError:
        pass
    
    #print(payout2_memory)
    
    
    
    if (payout_memory_time > 2):
        
        payout_memory_file = open("payout_memory.txt","w")
        payout_memory_file.write(str(payout))
        client.publish("payout_reset","yes")
        client.publish("payout_total",str(payout))
        meter_payout_buffer = 0
        payout_speed_ms = (payout - payout_prev)/2
        payout_prev = payout
        
        
        payout2_memory_file = open("payout2_memory.txt","w")
        payout2_memory_file.write(str(payout2))
        client.publish("payout_reset2","yes")
        client.publish("payout_total2",str(payout2))
        meter_payout2_buffer = 0
        payout2_speed_ms = (payout2 - payout2_prev)/2
        payout2_prev = payout2
        
        
        calculation_time_prev = time.time()        
        payout_memory_time_prev = time.time()
        
    else:
        payout = meter_payout_buffer + payout_memory
        payout2 = meter_payout2_buffer + payout2_memory
        
        
    

################################COUNT TENSION#####################################
    tension = round(tension_raw - tension_offset , 3)
    tension2 = round(tension2_raw - tension2_offset , 3)
    #print(tension)

###############################COUNT LAT LONG GRAPNEL#####################################
    
    
    if (-0.000000001 < payout < 0.000000001):
        payout = 0.000000001
        
    if (water_depth < 0.000000001):
        water_depth = 0.000000001
    
    if ((math.pow(payout , 2) - math.pow(water_depth,2)) > 0):
        distance_Grap_m =  math.sqrt((math.pow(payout , 2) - math.pow(water_depth,2)))

    else:
        distance_Grap_m = 0
        
    
    #print(distance_Grap)
    
    if (distance_Grap_m < 0.000000001):
        distance_Grap_m = 0.000000001
        
    distance_Grap = distance_Grap_m/ 111000
    
    Lat_G = float(val_latitude - (distance_Grap * math.cos(heading* math.pi/180)))
    Lon_G = float(val_longitude - (distance_Grap * math.sin(heading* math.pi/180)))
   # print(str(payout) + str("|") + str(Lat_G))                
    
##########TRANSMIT DATA TO SPC##################################
    mqtt_transmit_time = time.time() - mqtt_transmit_time_prev
   

    #####spc status    
    message_time = time.time() - message_time_prev
    current_time = dt.datetime.now()
    day = current_time.day
    
    if (day != day_prev):
        fields = ['time', 'lat', 'long', 'wind speed','wind direct', 'heading', 'dp speed 1','dp speed 2','dp speed 3','dp speed 4']
        filename = str("DPS RECORD " ) + str(current_time.day)+str("-")+str(current_time.month)+str("-")+str(current_time.year) + str(".csv")    
        with open(filename, 'a') as csvfile:
            # creating a csv writer object
            csvwriter = csv.writer(csvfile)
            # writing the fields
            csvwriter.writerow(fields)
    
    
    day_prev = day
    
    
########## COUNT VESSEL SPEED ##################################            
    ship_time = time.time() - ship_time_prev
    if (ship_time > 3):  
        delta_latitude = (val_latitude - prev_val_latitude) * 111132
        delta_longitude = (val_longitude - prev_val_longitude) * 111132
        knot = round(sqrt(pow(delta_latitude, 2) +  pow(delta_longitude, 2)) / 3 *2, 2) 
        
        prev_val_latitude = val_latitude
        prev_val_longitude = val_longitude
        ship_time_prev = time.time()
        


if __name__ == "__main__":
    
    ##Mosquitto Mqtt Configuration
    client= paho.Client("GUI")
    client.on_message=on_message

    print("connecting to broker ",broker)
    client.connect(broker,port)#connect
    print(broker," connected")
    
    client.loop_start()
    print("Subscribing")

    client.subscribe("payout")
    client.subscribe("payout2")
    client.subscribe("tension")
    client.subscribe("tension2")
    
    client.subscribe("GPS/lat")	
    client.subscribe("GPS/long")
    client.subscribe("headingship")	
    client.subscribe("winddirect")
    client.subscribe("windspeed")
    
    client.subscribe("ship_x")	
    client.subscribe("ship_y")
    client.subscribe("lat_target")	
    client.subscribe("long_target")
    client.subscribe("long_error")
    client.subscribe("lat_error")	
    client.subscribe("station_keeping")
    client.subscribe("distance_G")	
    client.subscribe("graphnel_latitude")
    client.subscribe("graphnel_longitude")		
    client.subscribe("heading_G")		
        
    client.publish("MainControl", "active")
    client.publish("dummyval", str(0))

    ## QT5 GUI
    print("Graphical User Interface ")
    app = QApplication(sys.argv)
    
    view = QQuickView()
    app.setWindowIcon(QIcon("syergielogofix.png"))
    view.setTitle("SYERGIE CABLE MANAGEMENT SYSTEM")
    view.setGeometry(0, 0, 1300, 700)
    view.setSource(QUrl('main.qml'))

    mqttvalue = MQTTValue()
    w = MQTTValue()


    timer = QTimer()
    timer.timeout.connect(timerEvent)
    timer.start(10)

    context = view.rootContext()
    context.setContextProperty("mqttvalue", mqttvalue)

    root = view.rootObject()
    timer.timeout.connect(root.updateValue)
       
    view.show()
    sys.exit(app.exec_())


